V1.10 — SMALL RECESSED NUDGE SWITCH FIT TESTS

Start with nudge_switch_fit.stl: 14.1 mm square aperture.
Alternates: nudge_mx_14p0.stl (14.0 mm) and nudge_mx_14p2.stl (14.2 mm).

Each piece is 30 x 30 x 4 mm. Its switch mounting face is 2.5 mm below the outside face, leaving a 1.5 mm snap plate. The tapered well is 23 mm wide at the outside and 18 mm at the mounting face. This matches the V1.10 wall's switch-mounting geometry without the flipper button or reinforcement.

Print in the supplied orientation, with the outside face and wide well mouth facing the bed, to reproduce the wall's orientation. The 45-degree sides lead to a 1.95 mm mounting ledge around the aperture; that ledge may need bridging adjustments or localized support. Check that it prints cleanly and clear any support before fitting the switch.

Seat the actual switch from the recessed side. Check both clips, retention and removal. Fit the actual cap and press through its full travel, checking that the underside and edges clear the rim. These dimensions assume an MX-style switch; the actual switch and cap have not been measured.

A fully seated switch and unchanged cap move 2.5 mm inward compared with V1.9. Absolute button height and cap travel depend on the actual hardware.
