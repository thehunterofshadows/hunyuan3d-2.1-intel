V1.11 FRONT CORNER TEST KIT
============================

This kit tests the feel, alignment and print finish of the softened front-left
corner before printing four full cabinet panels. The right corner is mirrored.

Three new sample panels are exact cropped regions of the V1.11 cabinet.
The other two files are original, unchanged cabinet mounting pieces:
  corner_left_front_56.stl
  top_block_left_25.stl

Use those mounts from your existing parts or print the included copies.
The three panel samples do not lock together by themselves.

PRINTING
Keep the supplied STL orientations. The panel samples have their outside/show
faces on the bed; the two mounts have their usual cabinet print orientations.
The new edge treatment starts with a short bevel and blends into a 1 mm curve,
within a maximum 1.5 mm inward extent. The lid rim uses a smaller 1 mm
extent to keep its curved corner clean. Physical print finish has not yet been tested.
Use the same material, layer height and wall settings intended for the cabinet.

ASSEMBLY
Use the cabinet's existing hardware specification for these mounting points.
1. Join the side-wall and front-panel samples using corner_left_front_56.
   Their flat mating faces reproduce the full cabinet's flush front seam.
2. Attach top_block_left_25 to the side-wall sample at its matching side hole.
3. Place the lid sample on the top block and attach it at the matching top hole.
   The block reproduces the original 1 mm vertical lid-to-panel clearance.
4. Check the exposed front corner for comfortable feel, aligned profiles and
   clean printed surfaces. The lid seam remains by design.

The straight edges created by cropping are sample boundaries, not additional
edges of the full cabinet. Judge the original exterior corner and front rim.

This is a prototype fit/feel check, not a physical validation of the full cabinet.
See README-v1_11.md for complete design, printing and hardware assumptions.

PANEL FILES
  front_corner_lid_fit.stl
  front_corner_panel_fit.stl
  front_corner_wall_fit.stl
